package mypackage; // This should match exactly in your ASL file

import jason.asSemantics.*;
import jason.asSyntax.*;

public class MyAction extends DefaultInternalAction {
    @Override
    public Object execute(TransitionSystem ts, Unifier un, Term[] args) throws Exception {
        System.out.println("Internal action executed! Testing" + args[0]);
        int K = 9;

        return un.unifies(args[1], new NumberTermImpl(K));
    }
}